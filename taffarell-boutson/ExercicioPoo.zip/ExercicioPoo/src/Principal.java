
public class Principal {

	public static void main(String[] args) {

		Medicamento medic1 = new Medicamento();
		
		Medicamento medic2 = new Medicamento( 10, "dipirona", "azulim", "ta baum", 50, "dose meses");
		
		medic1.setId(20);
		medic1.setNome("Paracentamole");
		medic1.setPrincipioAtivo("Cortiocoid");
		medic1.setUnd("La na pqp");
		medic1.setQtdeEstoque(512);
		medic1.setDataValidade("Dois anos");

		System.out.println("Id: "+medic1.getId());
		System.out.println("Nome: "+medic1.getNome());
		System.out.println("Principio Ativo: "+medic1.getPrincipioAtivo());
		System.out.println("Localiz��o: "+medic1.getUnd());
		System.out.println("Quantidade em Estoque: "+medic1.getqtdeEstoque());
		System.out.println("Data de Validade: "+medic1.getDataValidade());
		
		System.out.println( );
		
		System.out.println("Id: "+ medic2.getId());
		System.out.println("Nome: "+medic2.getNome());
		System.out.println("Principio Ativo: "+medic2.getPrincipioAtivo());
		System.out.println("Localiz��o: "+medic2.getUnd());
		System.out.println("Quantidade em Estoque: "+medic2.getqtdeEstoque());
		System.out.println("Data de Validade: "+medic2.getDataValidade());
		
		
		
	}

}
