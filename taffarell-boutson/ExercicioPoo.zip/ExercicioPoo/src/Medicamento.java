
public class Medicamento {
	
	private int id;
	private String nome;
	private String principioAtivo;
	private String und;
	private int qtdeEstoque;
	private String dataValidade;
	
	
	public Medicamento(){
		
	}
	
	public Medicamento(int id, String nome, String principioAtivo, String und, int qtdeEstoque, String dataValidade){
		this.id = id;
		this.nome = nome;
		this.principioAtivo = principioAtivo;
		this.und = und;
		this.qtdeEstoque = qtdeEstoque;
		this.dataValidade = dataValidade;
		
		
		
	}

	
	//Get e set ID
	public int getId(){
		return this.id;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
	//Get e set nome
	public String getNome(){
		return this.nome;
	}
	public void setNome(String nome){
		this.nome = nome;
	}
	
	//Get e set principioAtivo
	
	public String getPrincipioAtivo(){
		return this.principioAtivo;	
	}
	
	public  void setPrincipioAtivo (String principioAtivo){
		this.principioAtivo = principioAtivo;
	}
	
	//Get e set und
	
	public String getUnd(){
		return this.und;
	}
	
	public void setUnd(String und){
		this.und = und;
	}
	
	//Get e ser qtdeEstoque
	
	public int getqtdeEstoque(){
		return this.qtdeEstoque;
	}
	
	public void setQtdeEstoque(int qtdeEstoque){
		this.qtdeEstoque = qtdeEstoque;
	}
	
	//Get e set dataValidade
	
	public String getDataValidade(){
		return this.dataValidade;
	}
	
	public void setDataValidade(String dataValidade){
		this.dataValidade = dataValidade;
	}
}
