
public class Automovel {
	
	private int id;
	private String fabricante;
	private String modelo;
	private String cor;
	private String placa;
	private String chassi;
	private int ano;
	

	public String retornaDados() {
		return "Automovel Id: " + id + "\nFabricante: " + fabricante + "\nModelo: " + modelo + "\nCor: " + cor + "\nPlaca: "
				+ placa + "\nChassi: " + chassi + "\nAno: " + ano ;
	}

	public Automovel(){
		
	}
	
	public Automovel (int id,String fabricante,String modelo,String cor,String placa,String chassi, int ano ){
		
		this.id = id;
		this.fabricante = fabricante;
		this.modelo = modelo;
		this.cor = cor;
		this.placa = placa;
		this.chassi = chassi;
		this.ano = ano;
	}
	
	
	//Get e Set Id
	public int getId(){
		return this.id;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
	
	//Get e Set Fabricante
	public String getFabricante(){
		return this.fabricante;
	}
	
	public void setFabricante (String fabricante){
		this.fabricante = fabricante;
	}
	
	
	//Get e Set Modelo
	public String getModelo(){
		return this.modelo;
	}
	
	public void setModelo(String modelo){
		this.modelo = modelo ;
	}
	
	
	//Get e Set Cor
	public String getCor(){
		return this.cor;
	}
	
	public void setCor(String cor){
		this.cor = cor ;
	}
	
	
	//Get e Set Placa
	public String getPlaca(){
		return this.placa;
	}
	
	public void setPlaca(String placa){
		this.placa = placa;
	}
	
	
	//Get e Set Chassi
	public String getChassi(){
		return this.chassi;
	}
	
	public void setChassi(String chassi){
		this.chassi = chassi;
	}
	
	//Get e Set Ano
	public int getAno(){
		return this.ano;
	}
	
	public void setAno(int ano){
		this.ano = ano;
	}

}
