import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

	static ArrayList<Automovel> listaAutomovel = new ArrayList <Automovel>();
	static Scanner teclado = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		int op=0;
		
		do{
			System.out.println("1 � Inserir\n2 � Listar\n3 � Sair\nDigite a op��o:");
			
			op = teclado.nextInt();
			
			if(op==1){
				inserirAutomovel();
			}
			
			else if(op==2){
				listarAutomovel();
			}
		}
		
		while(op!=3);
		
}
	
	public static void inserirAutomovel(){
		
		System.out.println("Digite a ID: ");
		int id = teclado.nextInt();
		
		System.out.println("Digite o Fabricante: ");
		String fabricante = teclado.next();
		
		System.out.println("Digite o Modelo: ");
		String modelo = teclado.next();
				
		System.out.println("Digite a cor: ");
		String cor = teclado.next();
		
		System.out.println("Digite a placa: ");
		String placa = teclado.next();
		
		System.out.println("Digite o Chassi: ");
		String chassi = teclado.next();
		
		System.out.println("Digite o ano: ");
		int ano = teclado.nextInt();
		
		Automovel a = new Automovel(id, fabricante, modelo, cor, placa, chassi, ano);
		
		listaAutomovel.add(a);
		
		
	}
	
	
	
	public static void listarAutomovel(){
		
		for (int i = 0; i < listaAutomovel.size(); i++) {
			Automovel b = listaAutomovel.get(i);
			System.out.println(b.retornaDados());
		}
		
		
		
		
	}

}
